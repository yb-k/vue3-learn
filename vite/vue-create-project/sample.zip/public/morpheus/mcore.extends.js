
(function(window, undefined) {

var 
thisFileName = "mcore.extends.js",

importFiles = [];

M.ScriptLoader.writeScript( importFiles, M.ScriptLoader.scriptPath(thisFileName) );

})(window);